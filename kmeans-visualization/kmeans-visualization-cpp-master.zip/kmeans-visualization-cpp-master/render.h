#include <SDL2/SDL_stdinc.h>
#pragma one
#include "Entity.h"
#include <iostream>
#include <SDL2/SDL_ttf.h>

class render {

public:
    render(const char *window_tile, int w_width, int w_heigh);
    bool isRunning = true;
    SDL_Texture *loadTexture(const char *file_name);
    void rendering(Entity &tex, SDL_Rect *rect);
    void setColor(int r, int g, int b);
    void fillRect(SDL_Rect *rect, int r, int g, int b);
    void cleanUp();
    void clear();
    void display();
    SDL_Window *getWindow() {
        return window;
    }
    SDL_Renderer *getRender() {
        return renderer;
    }


private:
    SDL_Window *window;
    SDL_Renderer *renderer;

};





