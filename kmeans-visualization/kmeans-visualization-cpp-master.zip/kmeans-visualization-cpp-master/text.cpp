#include "text.h"
#include <SDL2/SDL_render.h>
#include <SDL2/SDL_surface.h>

void text::setFont(const char *c, int fontsize) {
    Arial = TTF_OpenFont(c, fontsize);
}
void text::setTex(std::string str, SDL_Color &color, SDL_Renderer *ren) {
    this->surf = TTF_RenderText_Solid(Arial, str.c_str(), color);
    this->tex = SDL_CreateTextureFromSurface(ren, this->surf);
    SDL_FreeSurface(this->surf);
}

void text::blitText(SDL_Renderer *ren, SDL_Rect *dst) {
    SDL_RenderCopy(ren, this->tex, NULL, dst);
    SDL_DestroyTexture(this->tex);
}

