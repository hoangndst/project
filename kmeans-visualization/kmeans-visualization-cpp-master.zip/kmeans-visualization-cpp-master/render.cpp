#include "render.h"
#include <SDL2/SDL_pixels.h>
#include <SDL2/SDL_rect.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_render.h>
#include <SDL2/SDL_stdinc.h>
#include <SDL2/SDL_surface.h>
#include <SDL2/SDL_ttf.h>
using namespace std;

render::render(const char *window_tile, int w_width, int w_heigh) {
    SDL_Init(SDL_INIT_EVERYTHING);

    window = SDL_CreateWindow(window_tile, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, w_width, w_heigh, SDL_WINDOW_SHOWN);
    if (window == NULL) {
        cout << "Window failed to init " << SDL_GetError() << endl;
  }

    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
}

SDL_Texture *render::loadTexture(const char *file_name) {
    SDL_Texture *texture = NULL;
    texture = IMG_LoadTexture(renderer, file_name);
    if (texture == NULL) {
        cout << "Failed to load Texture " << SDL_GetError() << endl;
    }

    return texture;
}

void render::clear() {
    SDL_RenderClear(renderer);
}

void render::cleanUp() {
    SDL_DestroyWindow(window);
}

void render::rendering(Entity &tex, SDL_Rect *rect) {
    SDL_Rect dst;
    dst.h = tex.getcurrentFrame().h;
    dst.w = tex.getcurrentFrame().w;
    dst.x = tex.getX(); // bgX;
    dst.y = tex.getY(); // bgY;
    SDL_RenderCopy(renderer, tex.getTex(), rect, &dst);
}
void render::display() {

    SDL_SetRenderDrawColor(renderer, 0, 43, 54, 0);
    SDL_RenderPresent(renderer);
}


void render::setColor(int r, int g, int b) {
    SDL_SetRenderDrawColor(renderer, r, g, b, 255);
}
void render::fillRect(SDL_Rect *rect, int r, int g, int b) {
    setColor(r, g, b);
    SDL_RenderFillRect(renderer, rect);
}


