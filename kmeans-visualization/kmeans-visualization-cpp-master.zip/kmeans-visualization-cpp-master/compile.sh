#!/usr/bin/env bash
g++ *.cpp -lSDL2 -lSDL2_image -lSDL2_ttf
