#include <SDL2/SDL_mouse.h>
#include <SDL2/SDL_pixels.h>
#include <SDL2/SDL_stdinc.h>
#include <algorithm>
#include <cmath>
#include <iostream>
#include "render.h"
#include <SDL2/SDL_events.h>
#include <SDL2/SDL_rect.h>
#include <SDL2/SDL_render.h>
#include <SDL2/SDL_timer.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <string>
#include "text.h"
#include <stdlib.h>
#include <time.h>
using namespace std;
int lastFrame, frameCount;

int getIndex(vector<double> v, double K) {
    auto it = find(v.begin(), v.end(), K);
    if (it != v.end()) {
        int index = it - v.begin();
        return index;
    }
    return 0;
}
double dis(vector<double> vect1, vector<double> vect2) {
    return double(sqrt(pow((vect1[0] - vect2[0]), 2) + pow((vect1[1] - vect2[1]), 2)));
} 


int main(int argc, char *argv[]) {
    
    render window("v1.0", 1200 , 700);
    int frame = 0;
    int count = 0;
    // panel    
    SDL_Rect panel_1 = {10, 10, 1180, 600};
    SDL_Rect panel_2 = {11, 11, 1178, 598};

    // K
    SDL_Rect K_1 = {50, 640, 30, 30};
    SDL_Rect K_2 = {82, 640, 96, 30};
    SDL_Rect K_3 = {180, 640, 30, 30};
    SDL_Rect K_b = {83, 641, 94, 28};

    
    // Run
    SDL_Rect run_b = {180 + 30 + 50, 640, 80, 30};
    SDL_Rect run = {180 + 30 + 50 + 1, 641, 78, 28};
    
    // random
    SDL_Rect rdm_b = {390, 640, 110, 30};
    SDL_Rect rdm = {390 + 1, 641, 108, 28};
    
    // number of p
    SDL_Rect p1_b = {550, 620, 180, 40};
    SDL_Rect p1 = {550 + 1, 621, 180 - 2, 40 - 2};
    SDL_Rect p2_b = {710, 620, 110, 40};
    SDL_Rect p2 = {711, 621, 110 - 2, 40 - 2};
    
    // error
    int temp = 35;
    int temp_y = 620 + 35;
    SDL_Rect e1_b = {550, temp_y, 180, temp};
    SDL_Rect e1 = {550 + 1, temp_y + 1, 180 - 2, temp - 2};
    SDL_Rect e2_b = {710, temp_y, 110, temp};
    SDL_Rect e2 = {711, temp_y + 1, 110 - 2, temp - 2};

    // algorithm
    SDL_Rect a1_b = {870, 640, 150, 30};
    SDL_Rect a1 = {870 + 1, 641, 150 - 2, 28};
    
    // reset
    SDL_Rect rs1_b = {1070, 640, 80, 30};
    SDL_Rect rs1 = {1070 + 1, 641, 80 - 2, 28};


    TTF_Init();
    text texPos;
    texPos.setFont("font/NotoSansMono-Bold.ttf", 100);
    SDL_Color texPos_color = {42, 161, 152};

    // K
    text _k1;
    _k1.setFont("font/NotoSansMono-Bold.ttf", 100);
    SDL_Color _k1_color = {255, 255, 255};
    SDL_Rect _k1_rect = {51, 638, 30, 30};

    text _k2;
    _k2.setFont("font/NotoSansMono-Bold.ttf", 100);
    SDL_Color _k2_color = {255, 255, 255};
    SDL_Rect _k2_rect = {184, 647 - 12, 20, 40};

    // run
    text _run;
    _run.setFont("font/Sans.ttf", 60);
    SDL_Color _run_color = {255, 255, 255};
    SDL_Rect _run_rect = {184 + 84, 647 - 8, 60, 30};

    // random
    text _random;
    _random.setFont("font/Sans.ttf", 100);
    SDL_Color _random_color = {255, 255, 255};
    SDL_Rect _random_rect = {184 + 84 + 84 + 43, 647 - 8, 100, 30};

    // points
    text _points;
    _points.setFont("font/Sans.ttf", 100);
    SDL_Color _points_color = {255, 255, 255};
    SDL_Rect _points_rect = {555, 630 - 8, 150, 25};

    // error
    text _error;
    _error.setFont("font/Sans.ttf", 100);
    SDL_Color _error_color = {255, 255, 255};
    SDL_Rect _error_rect = {590, 665 - 10, 60, 30};
    // algorithm
    text _algorithm;
    _algorithm.setFont("font/Sans.ttf", 100);
    SDL_Color _algorithm_color = {255, 255, 255};
    SDL_Rect _algorithm_rect = {870 + 13, 647 - 8, 120, 30};
    // reset
    text _reset;
    _reset.setFont("font/Sans.ttf", 100);
    SDL_Color _reset_color = {255, 255, 255};
    SDL_Rect _reset_rect = {1085 - 6, 647 - 5, 60, 30};
    // error
    text ERROR;
    int error = 0;
    ERROR.setFont("font/Sans.ttf", 24);
    SDL_Color er = {255, 255, 255};
    SDL_Rect error_rect = {745, 660, 35, 20};
    // number of points
    

    SDL_Color random_color[8];
    random_color[0] = {220, 50, 47};
    random_color[1] = {133, 153, 0};
    random_color[2] = {38, 139, 210};
    random_color[3] = {181, 137, 0};
    random_color[4] = {108, 113, 196};
    random_color[5] = {147, 161, 161};
    random_color[6] = {225, 225, 225};
    random_color[7] = {0, 0, 0};

    vector<vector<double>> points;
    vector<vector<double>> clusters;
    vector<double> labels;
    int K = 0;

    while(window.isRunning) {
        lastFrame = SDL_GetTicks();
        static int lastTime;
        if (lastFrame >= (lastTime+1000)) {
            lastTime = lastFrame;
            frameCount = 0;
            count++;
        }

        window.fillRect(&panel_1, 255, 255, 255);
        window.fillRect(&panel_2, 0, 20, 26);
        window.fillRect(&K_1, 88, 110, 117);
        window.fillRect(&K_2, 88, 110, 117);
        window.fillRect(&K_3, 88, 110, 117);
        window.fillRect(&K_b, 0, 20, 26);
        window.fillRect(&run_b, 255, 255, 255);
        window.fillRect(&run, 88, 110, 117);
        window.fillRect(&rdm_b, 255, 255, 255);
        window.fillRect(&rdm, 88, 110, 117);
        window.fillRect(&p1_b, 220, 50, 47);
        window.fillRect(&p1, 88, 110, 117);
        window.fillRect(&p2_b, 220, 50, 47);
        window.fillRect(&p2, 88, 110, 117);
        window.fillRect(&e1_b, 220, 50, 47);
        window.fillRect(&e1, 88, 110, 117);
        window.fillRect(&e2_b, 220, 50, 47);
        window.fillRect(&e2, 88, 110, 117);
        window.fillRect(&a1_b, 255, 255, 255);
        window.fillRect(&a1, 88, 110, 117);
        window.fillRect(&rs1_b, 255, 255, 255);
        window.fillRect(&rs1, 88, 110, 117);
        _k1.setTex("-", _k1_color, window.getRender());
        _k1.blitText(window.getRender(), &_k1_rect);
        _k2.setTex("+", _k1_color, window.getRender());
        _k2.blitText(window.getRender(), &_k2_rect);
        _run.setTex("RUN", _k1_color, window.getRender());
        _run.blitText(window.getRender(), &_run_rect);
        _random.setTex("RANDOM", _k1_color, window.getRender());
        _random.blitText(window.getRender(), &_random_rect);
        _points.setTex("NUMBER OF POINTS", _k1_color, window.getRender());
        _points.blitText(window.getRender(), &_points_rect);
        _error.setTex("ERROR", _k1_color, window.getRender());
        _error.blitText(window.getRender(), &_error_rect);
        _algorithm.setTex("ALGORITHM", _k1_color, window.getRender());
        _algorithm.blitText(window.getRender(), &_algorithm_rect);
        _reset.setTex("RESET", _k1_color, window.getRender());
        _reset.blitText(window.getRender(), &_reset_rect);



        int mouse_x, mouse_y;
        SDL_GetMouseState(&mouse_x, &mouse_y);
        // cout << mouse_x << " " << mouse_y << endl;
        if ((11 < mouse_y && mouse_y < 11 + 598) && (11 < mouse_x && mouse_x < 11 + 1178)) {
            SDL_Rect mouse_pos = {mouse_x, mouse_y, 10, 10};
            SDL_Rect text_poss = {mouse_x + 20, mouse_y, 100, 20};
            window.fillRect(&mouse_pos, 42, 161, 152);
            texPos.setTex("[" + to_string(mouse_x - 11) + " : " + to_string(mouse_y - 11) + "]", texPos_color, window.getRender());
            texPos.blitText(window.getRender(), &text_poss);
            
            //window.display();
        }


        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                cout << "Press Exit" << endl; 
                window.isRunning = false;
                window.clear();
            }
            if (event.type == SDL_MOUSEBUTTONDOWN) {
                if ((11 < mouse_y && mouse_y < 11 + 598) && (11 < mouse_x && mouse_x < 11 + 1178)) {
                    labels.clear();
                    vector<double> tmp;
                    int x = mouse_x - 11;
                    int y = mouse_y - 11;
                    tmp.push_back(x);
                    tmp.push_back(y);
                    points.push_back(tmp);
                    tmp.clear();
                }
                // Click on K- button
                if ((640 < mouse_y && mouse_y < 640 + 30) && (50 < mouse_x && mouse_x < 50 + 30)) {
                    cerr << "K- exc" << endl;
                    if (K > 0) K = K - 1;
                }
                // Click on K+ button
                if ((640 < mouse_y && mouse_y < 640 + 30) && (180 < mouse_x && mouse_x < 180 + 30)) {
                    cerr << "K+ exc" << endl;
                    if (K < 8) K = K + 1;
                }

                //Click random
                if ((640 < mouse_y && mouse_y < 640 + 30) && (390 < mouse_x && mouse_x < 390 + 110)) {
                //     clusters.clear();
                    clusters.clear();
                //     labels.clear();
                    labels.clear();
                    for (int i = 0; i < K; i++) {
                        int r1 = 10 + rand() % (1178 - 10 + 1 - 10);
                        int r2 = 10 + rand() % (598 - 10 + 1 - 10);
                        vector<double> rand;
                        rand.push_back(r1);
                        rand.push_back(r2);
                        clusters.push_back(rand);
                        rand.clear();
                    }
                    cerr << "Random exc" << endl;
                //     cl = [randint(10, 1178 - 10), randint(10, 598 - 10)]
                //     clusters.append(cl)
                // print("RANDOM executed")
                }
                // run
                if ((640 < mouse_y && mouse_y < 640 + 30) && (180 + 30 + 50 < mouse_x && mouse_x < 180 + 30 + 50 + 80) && clusters.size() != 0) {
                    // change points color
                    labels.clear();
                    for (int i = 0; i < points.size(); i++) {
                        vector<double> distance_to_cl;
                        for (int j = 0; j < clusters.size(); j++) {
                            double tmp1 = dis(points[i], clusters[j]);
                            distance_to_cl.push_back(tmp1);
                        }
                        double min_dis = *min_element(distance_to_cl.begin(), distance_to_cl.end());
                        labels.push_back(getIndex(distance_to_cl, min_dis));
                    }
                    // change clusters pos
                    for (int i = 0; i < clusters.size(); i++) {
                        double sum_x = 0;
                        double sum_y = 0;
                        double count = 0;
                        for (int j = 0; j < points.size(); j++) {
                            if (labels[j] == i) {
                                sum_x = sum_x + points[j][0];
                                sum_y = sum_y + points[j][1];
                                count = count + 1;
                                
                            }
                        }
                        if (count != 0) {
                            clusters[i][0] = sum_x/count;
                            clusters[i][1] = sum_y/count;
                            
                        }
                    }
                    cerr << "run exc" << endl;
                }
                // RESET
                if ((640 < mouse_y && mouse_y < 640 + 30) && (1070 < mouse_x && mouse_x < 1070 + 80)) {
                    points.clear();
                    clusters.clear();
                    labels.clear();
                    K = 0;
                    cerr << "reset exc" << endl;
                }
            }
        }
        // draw points_null
        for (int i = 0; i < points.size(); i++) {
            SDL_Rect back_points = {int(points[i][0]), int(points[i][1]), 10, 10};
            window.fillRect(&back_points, 255, 255, 255);
            //window.display();
            if (labels.size() == 0) {
                SDL_Rect points_null = {int(points[i][0] + 1), int(points[i][1] + 1), 8, 8};
                window.fillRect(&points_null, 0, 0, 0);
            } else {
                SDL_Rect points_null = {int(points[i][0] + 1), int(points[i][1] + 1), 8, 8};
                window.fillRect(&points_null, random_color[int(labels[i])].r, random_color[int(labels[i])].g, random_color[int(labels[i])].b);
            }
        }
        // draw random points
        for (int i = 0; i < clusters.size(); i++) {
            SDL_Rect random_points = {int(clusters[i][0]), int(clusters[i][1]), 14, 14};
            window.fillRect(&random_points, 255, 255, 255);
            SDL_Rect random_points_1 = {int(clusters[i][0]) + 3, int(clusters[i][1]) + 3, 8, 8};
            window.fillRect(&random_points_1, random_color[i].r, random_color[i].g, random_color[i].b);
        }

        //error
        error = 0;
        if (labels.size() != 0 && clusters.size() != 0) {
            for (int i = 0; i < points.size(); i++) {
                error = error + int(dis(points[i], clusters[labels[i]]));
            } 
        }
        if (error > 0) {
            ERROR.setTex(to_string(error), er, window.getRender());
            ERROR.blitText(window.getRender(), &error_rect);
        }
        SDL_Rect demo = {755, 630 - 5, 12, 24};
        if (points.size() >= 10) {
            demo = {755 - 10 , 630 - 5, 28, 24};
        }

        ERROR.setTex(to_string(points.size()), er, window.getRender());
        ERROR.blitText(window.getRender(), &demo);
        
        SDL_Rect K_value = {148 - 20, 645 - 2, 12, 24};
        ERROR.setTex(to_string(K), er, window.getRender());
        ERROR.blitText(window.getRender(), &K_value);

        window.display();
        window.clear();
        
    }

    TTF_Quit();
    if (count > 3) window.isRunning = false;
    window.cleanUp();
}
