# kmeans-visualization-cpp
K-means Algorithm Visualization
# Kmeans Clusters

## Chương trình mô phỏng thuật toán Kmeans Clusters thực hiện qua các bước cơ bản:
Input dữ liệu.
Chọn số điểm.
Random số điểm
Bấm RUN và thuật toán sẽ đi tìm các nhóm điểm.

## Bài báo cáo
<a href = "https://github.com/hoangndst/kmeans-visualization-cpp/blob/master/report/report.pdf" target = "_blank"><p>Báo cáo</p></a>

# Preview
## Kmeans Algorithm Visualization
![GUI Tool](img/one.png)


2020 @ arch-techs

