Dự án này đã được khởi động bằng [Tạo ứng dụng React] (https://github.com/facebook/create-react-app).

Trước khi chạy dự án này, bạn cần phải cài đặt Node.js tại máy của bạn: 
Link để cài đặt Node.js: https://nodejs.org/en/

Trong trường hợp bạn đã cài đặt Node.js, bạn có thể chạy dự án này bằng cách thực thi lệnh sau:

Vào folder dự án và mở terminal:
1.
    npm install
2.
    npm start

Chạy ứng dụng ở chế độ phát triển.
Mở http://localhost:3000/ để có thể chạy chương trình.

Ứng dũng đã mô phỏng 3 thuật toán sắp xếp cơ bản những chưa được hoàn thiện.

Người dùng có thể cập nhật tại https://github.com/hoangndst

Cảm ơn bạn đã sử dụng dự án này!